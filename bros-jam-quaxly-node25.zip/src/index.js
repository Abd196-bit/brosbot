import { ActivityType, Client, Events, GatewayIntentBits } from 'discord.js';
import { getConfig } from './config.js';
import { handleCommand } from './commands.js';
import { handlePollInteraction, pollMessage } from './poll-ui.js';
import { getRepository } from './poll-repository.js';

const config = getConfig();
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, async (readyClient) => {
  readyClient.user.setActivity(process.env.BOT_ACTIVITY || 'BRO’S JAM • /poll', { type: ActivityType.Playing });
  console.log(`Ready as ${readyClient.user.tag}.`);
  for (const poll of getRepository().list()) {
    if (!poll.messageId) continue;
    try {
      const channel=await readyClient.channels.fetch(poll.channelId);
      await channel.messages.edit(poll.messageId,pollMessage(poll));
      console.log('Updated poll message',poll.messageId);
    } catch(error) { console.error('Could not refresh poll message',poll.messageId,error.code || error.name); }
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) await handleCommand(interaction, config);
    else if (interaction.customId && /^(draft|edit|poll|vote|polltext):/.test(interaction.customId)) await handlePollInteraction(interaction);
    else return;
  } catch (error) {
    console.error('Interaction failed:', error.code || error.name, error.message);
    try {
      const payload = { content: error.message?.slice(0, 1500) || 'Unable to complete this action. Please try again.', allowedMentions: { parse: [] } };
      if (interaction.deferred) await interaction.editReply(payload);
      else if (!interaction.replied) await interaction.reply({ ...payload, flags: 64 });
    } catch { console.error('Could not respond to expired interaction.'); }
  }
});

client.login(config.token);
