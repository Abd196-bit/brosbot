import { cert, getApps, initializeApp } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

let syncing = false;
let firestore;

export function firebaseConfigured() {
  return Boolean(process.env.FIREBASE_SERVICE_ACCOUNT_JSON && process.env.FIREBASE_PROJECT_ID);
}

function database() {
  if (firestore) return firestore;
  if (!firebaseConfigured()) throw new Error('Firebase is not configured.');
  let serviceAccount;
  try {
    serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
  } catch {
    throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is not valid JSON.');
  }
  const app = getApps().find(app => app.name === 'bros-jam-votes') || initializeApp({
    credential: cert(serviceAccount),
    projectId: process.env.FIREBASE_PROJECT_ID,
  }, 'bros-jam-votes');
  firestore = getFirestore(app);
  return firestore;
}

// Every event is stored by its UUID. Retrying after a host restart overwrites
// the same document instead of producing duplicate votes.
export async function flushFirebaseEvents(repository) {
  if (!firebaseConfigured() || syncing) return;
  syncing = true;
  try {
    const db = database();
    for (const event of repository.pendingFirebaseEvents(100)) {
      try {
        await db.collection('discordVoteEvents').doc(event.id).set({
          ...event,
          syncedAt: new Date().toISOString(),
        });
        repository.completeFirebaseEvent(event.id);
      } catch (error) {
        console.error('Firebase sync paused:', error.message);
        break;
      }
    }
  } finally {
    syncing = false;
  }
}
